// errors.h
#define IS_UNK_OP    0
#define IS_TOO_FEW   1
#define IS_NON_VALID 2
#define IS_STACK_OF  3
#define IS_STACK_UF  4
#define IS_EMT_STACK 5
